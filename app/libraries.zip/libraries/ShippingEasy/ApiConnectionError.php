<?php

class ShippingEasy_ApiConnectionError extends ShippingEasy_Error
{
}
