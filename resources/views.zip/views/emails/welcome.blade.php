<h1>Welcome {{ $user->name }}!</h1>
<p>Your membership has been approved at Security Entrepreneurs Association.</p>
<p>Thank you for joining us!</p>
