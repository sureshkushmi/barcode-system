<!--begin::Footer-->
<footer class="app-footer">
        <!--begin::To the end
        <div class="float-end d-none d-sm-inline">Anything you want</div>-->
        <!--end::To the end-->
        <!--begin::Copyright-->
        <strong>
        Copyright &copy; {{ date('Y') }}&nbsp;

          <a href="#" class="text-decoration-none">Barcode System</a>.
        </strong>
        All rights reserved.
        <!--end::Copyright-->
      </footer>
      <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->
  </body>
  <!--end::Body-->
</html>
