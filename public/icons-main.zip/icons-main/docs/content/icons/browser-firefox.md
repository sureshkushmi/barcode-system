---
title: Browser Firefox
categories:
  - Brand
tags:
  - gecko
added: 1.10.0
---
