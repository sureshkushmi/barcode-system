---
title: Arrow up left square fill
categories:
  - Shape arrows
tags:
  - arrow
  - square
---
