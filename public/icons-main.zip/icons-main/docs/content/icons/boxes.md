---
title: Boxes
categories:
  - Real world
tags:
  - cardboard
  - package
  - cube
---
