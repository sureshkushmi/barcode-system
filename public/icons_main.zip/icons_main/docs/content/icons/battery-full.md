---
title: Battery full
categories:
  - Devices
tags:
  - power
  - charge
---
