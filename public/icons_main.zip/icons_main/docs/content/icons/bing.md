---
title: Bing
categories:
  - Brand
tags:
  - search
  - microsoft
added: 1.11.0
---
