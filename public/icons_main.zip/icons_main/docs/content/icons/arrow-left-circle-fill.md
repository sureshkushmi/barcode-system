---
title: Arrow left circle fill
categories:
  - Shape arrows
tags:
  - arrow
  - circle
---
