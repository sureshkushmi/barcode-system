---
title: Beaker fill
categories:
  - Real world
tags:
  - beaker
  - science
  - measure
  - experiment
---
